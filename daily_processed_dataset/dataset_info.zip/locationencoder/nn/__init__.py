from .siren import SirenNet
from .fcnet import FCNet
